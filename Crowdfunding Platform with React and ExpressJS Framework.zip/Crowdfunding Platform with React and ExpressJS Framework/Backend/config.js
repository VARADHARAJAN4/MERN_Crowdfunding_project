var PaytmConfig = {
  mid: process.env.mid,
  key: process.env.key,
  website: process.env.website,
};
module.exports.PaytmConfig = PaytmConfig;
