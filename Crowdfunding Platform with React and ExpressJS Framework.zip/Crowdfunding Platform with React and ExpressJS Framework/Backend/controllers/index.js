module.exports = {
  campaign: require("./campaign"),
  user: require("./user"),
  payment: require("./payment"),
  donation: require("./donation"),
  query: require("./query"),
};
